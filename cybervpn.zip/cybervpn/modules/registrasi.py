from cybervpn import *
from telethon import events, Button
import random
import sys
from datetime import datetime, timedelta
import asyncio
import time

# Fungsi untuk registrasi
async def registrasi_handler(event):
    chat = event.chat_id
    sender = await event.get_sender()
    user_id = str(event.sender_id)

    async def get_username(user_conv):
        await event.edit('**Masukkan username kamu:**')
        user_msg = await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
        return user_msg.raw_text

    async with bot.conversation(chat) as user_conv:
        username = await get_username(user_conv)

    saldo = 0
    level = "user"
    register_user(user_id, saldo, level)

    today = datetime.now()
    msg = f"""
**━━━━━━━━━━━━━━━━**
**⟨Registrasi Sukses⟩**
**━━━━━━━━━━━━━━━━**
**» ID Pengguna:** `{user_id}`
**» Username:** `{username}`
**» Saldo:** `IDR.0`
**» Ketik /menu untuk login**
**━━━━━━━━━━━━━━━━**
**» Tanggal Registrasi:** `{today.strftime('%Y-%m-%d %H:%M:%S')}`
**» 💌@MasAnsor**
**━━━━━━━━━━━━━━━━**
    """
    inline = [
        [Button.inline("[ login ]", "menu")]
    ]
    await event.respond(msg, buttons=inline)

    return user_id  # Kembalikan user_id setelah registrasi

# Fungsi untuk top-up
async def topup_user(event, user_id):
    async def topup_user_(event):
        random_numbers = [random.randint(0, 99) for _ in range(3)]
        async with bot.conversation(chat) as nominal_conv:
            await event.edit('**Input nominal topup:**')
            nominal_msg = await nominal_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            nominal = int(nominal_msg.raw_text.strip()) if nominal_msg.raw_text.strip().isdigit() else 0

        if nominal < 10000:
            await event.respond("**Nominal tidak memenuhi syarat. Minimal transaksi RP.10.000.**")
            sys.exit()  
        else:
            result = sum(random_numbers) + nominal
            waktu_awal = datetime.now()
            waktu_expired = waktu_awal + timedelta(minutes=1)

        await event.edit("Processing...")
        await event.edit("`Processing transaction`")
        time.sleep(1)
        await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒`")
        time.sleep(1)
        await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
        time.sleep(1)
        await event.edit("`Processing... 100%\n█████████████████████████ `")

        try:
            dana_gopay_list = tampilkan_dana_gopay()

            if dana_gopay_list:
                dana_gopay_str = "\n".join(dana_gopay_list)
                msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
**     🌹 Informasi Pembayaran 🌹**
**◇━━━━━━━━━━━━━━━━━◇**
{dana_gopay_str}
**◇━━━━━━━━━━━━━━━━━◇**
** Nominal yang harus di bayar:**
** TRX:** RP.`{result}`
** Kode transaksi:** `{sum(random_numbers)}`
** Waktu transaksi hanya 1 menit**
** Waktu transaksi: {waktu_awal.strftime("%H:%M:%S")}**
** Expired transaksi: {waktu_expired.strftime("%H:%M:%S")}**
**◇━━━━━━━━━━━━━━━━━◇**
**Notice:** Setelah melakukan topup, harap kirim bukti transfer ke admin @MasAnsor untuk mempercepat proses transaksi!
**◇━━━━━━━━━━━━━━━━━◇**
                """
                buttons = [[Button.inline("‹ Main Menu ›", "menu")]]
                await event.respond(msg, buttons=buttons)
                await main(event)
            else:
                await event.respond("Data pengguna tidak tersedia saat ini.")

        except Exception as e:
            print(f'Error: {e}')
            await event.respond(f"Terjadi kesalahan: {e}")

    chat = event.chat_id
    sender = await event.get_sender()

    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await topup_user_(event)
        else:
            await event.answer(f'Akses Ditolak. Level: {level}', alert=True)
    except Exception as e:
        print(f'Error: {e}')

# Gabungkan Registrasi dan Top-up dengan Rule yang Ditetapkan
@bot.on(events.NewMessage(pattern=r"(?:/registrasi)$"))
@bot.on(events.CallbackQuery(data=b'registrasi'))
async def registrasi_and_topup_handler(event):
    chat = event.chat_id
    sender = await event.get_sender()
    user_id = str(event.sender_id)

    # Langkah Registrasi
    user_id = await registrasi_handler(event)

    # Ambil saldo pengguna dari database
    saldo = get_balance_from_db(user_id)

    if saldo == 0:
        # Jika saldo 0, beri tahu pengguna dan tawarkan top-up
        msg = """
**Saldo Anda saat ini 0.**
**Minimal saldo untuk registrasi adalah 10.000.**
Apakah Anda ingin melanjutkan top-up untuk mendaftar?
        """
        inline = [
            [Button.inline("Ya", "topup_yes"), Button.inline("Tidak", "topup_no")]
        ]
        await event.respond(msg, buttons=inline)
    else:
        # Jika saldo mencukupi
        await event.respond("Saldo Anda sudah mencukupi, registrasi berhasil.")
        # Tampilkan tombol menu untuk masuk ke sistem
        inline = [[Button.inline("[ login ]", "menu")]]
        await event.respond("Registrasi berhasil!", buttons=inline)

# Handler untuk Yes/No topup
@bot.on(events.CallbackQuery(data=b'topup_yes'))
async def topup_yes_handler(event):
    # Lanjutkan dengan proses top-up
    chat = event.chat_id
    sender = await event.get_sender()
    user_id = str(event.sender_id)
    await topup_user(event, user_id)

@bot.on(events.CallbackQuery(data=b'topup_no'))
async def topup_no_handler(event):
    # Jika pengguna memilih tidak top-up, beri tahu dan keluar
    await event.respond("Registrasi dibatalkan. Silakan coba lagi nanti.")
