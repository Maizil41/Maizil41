<?php
/*
 *********************************************************************************************************
 * Hotspotlogin daloRADIUS by Maizil https://t.me/maizil41
 * This program is free and not for sale. If you want to sell one, make your own, don't take someone else's work.
 * Don't change what doesn't need to be changed, please respect others' work
 * Copyright (C) 2024 - Mutiara-Wrt by <@maizil41>. 
 *********************************************************************************************************
*/ 
echo <<<END
<!doctype html>
<html lang="en">

<head>
    <title id="title"></title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="theme-color" content="#3B5998" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0; maximum-scale=1.0;" />
    <link rel="icon" type="image" href="assets/images/favicon.svg" sizes="32x32">
    <link rel="stylesheet" href="assets/style.css">
    <style> 
        .frame img {width: 100%; height: auto;}
    </style>
</head>

<body style="margin: 0 auto; height: 100%;">
    <div id="main" class="main">
        <div class="box">
            <div class="frame">
                <img src="assets/images/mutiara.png" alt="logo"><br>
            </div>
            <div class="box">
                <button id="btnvrc" class="small-button1" onclick="voucher();">
                    <i class="icon icon-ticket">&#xe802;</i> Voucher
                </button>
                <button id="btnmem" class="small-button" onclick="member()">
                    <i class="icon icon-user-circle-o">&#xf2be;</i> Member
                </button>
                <button id="qr" class="small-button3" onclick="window.location='https://maizil41.github.io/scanner';">
                    <i class="icon icon-qrcode">&#xe801;</i> QR Code
                </button>
            </div>
            <div class="box" id="infologin"></div>
            <form autocomplete="off" name="login" action="$loginpath" method="post" class="animated-input">
                <input type="hidden" name="dst" value="$(link-orig)" />
                <input type="hidden" name="popup" value="true" />
                <input class="username" name="username" type="hidden" value="$(username)" />

                <input type="hidden" name="challenge" value="$challenge">
                <input type="hidden" name="uamip" value="$uamip">
                <input type="hidden" name="uamport" value="$uamport">
                <input type="hidden" name="userurl" value="$userurl">

                <input class="username" name="UserName" type="text" id="user" class="form-use" placeholder="Username" required autofocus />
                <input type="hidden" id="pass" class="password" name="Password" placeholder="Password" required />
                
                <input type="hidden" name="button" value="Login">
                <button class="login-button" onClick='javascript:popUp("$loginpath?res=popup1&uamip=$uamip&uamport=$uamport")'>
                    <i class="icon icon-login">&#xe807;</i> MASUK
                </button>
                <button class="login-button" onclick="handleTrial()" id="trialButton">
                    <i class="icon icon-login">&#xe803;</i> GRATIS
                </button>
                <button class="login-button" onclick="window.location.href='/radiusbilling/';">
                    <i class="icon icon-login">&#xe803;</i> BELI
                </button>


            </form>

            <b>
            <table class="table">
                <tr>
                    <th>Paket</th>
                    <th>Aktif</th>
                    <th>Harga</th>
                </tr>
                <tr>
                    <td>Gratis</td>
                    <td>5 Menit</td>
                    <td>Rp.0</td>
                </tr>
                <tr>
                    <td>3 Jam</td>
                    <td>3 Jam</td>
                    <td>Rp.1000</td>
                </tr>
                <tr>
                    <td>Harian</td>
                    <td>1 Hari</td>
                    <td>Rp.5000</td>
                </tr>
                <tr>
                    <td>Mingguan</td>
                    <td>7 Hari</td>
                    <td>Rp.20000</td>
                </tr>
                <tr>
                    <td>Bulanan</td>
                    <td>30 Hari</td>
                    <td>Rp.50000</td>
                </tr>
            </table>
            <br/>
            <div class="frame">
                Voucher bisa dibeli melalui<br>
                Whatsapp: <a href="https://wa.me/+6285372687484" style="text-decoration: underline; color:#000;">0853-7268-7484</a>
            </div>
        </div>
    </div>

    <div id="pleaseWait" style="display:none; text-align: center; padding-top: 50%;">
        <img src="assets/images/mutiara.png" alt="" border="0" height="50" width="150"/>
      </a><br>
      <small><img src="assets/images/wait.gif"/> redirecting...</small>
    </p>
    <br><br>
    </div>

    <script type="text/javascript">
        var hostname = window.location.hostname;
        document.getElementById('title').innerHTML = hostname + " > login";

        document.login.username.focus();

        var infologin = document.getElementById('infologin');
        infologin.innerHTML = "Masukkan Kode Voucher<br>kemudian klik login.";

        var username = document.login.username;
        var password = document.getElementById('pass');

        function setpass() {
            var user = username.value.toLowerCase();
            username.value = user;
            password.value = user;
        }

        function voucher() {
            username.focus();
            username.onkeyup = setpass;
            username.placeholder = "Kode Voucher";
            username.style.borderRadius = "3px";
            password.type = "hidden";
            infologin.innerHTML = "Masukkan Kode Voucher<br>kemudian klik login.";
        }

        function member() {
            username.focus();
            username.onkeyup = null;
            username.placeholder = "Username";
            username.style.borderRadius = "3px 3px 0px 0px";
            password.type = "text";
            infologin.innerHTML = "Masukkan Username dan Password<br>kemudian klik login.";
        }

        function setCookie(name, value, days) {
            var expirationDate = new Date();
            expirationDate.setDate(expirationDate.getDate() + days);
            var cookieValue = name + '=' + value + '; expires=' + expirationDate.toUTCString() + '; path=/';
            document.cookie = cookieValue;
        }

        function getCookie(name) {
            var cookies = document.cookie.split(';');
            for (var i = 0; i < cookies.length; i++) {
                var cookie = cookies[i].trim();
                if (cookie.indexOf(name + '=') === 0) {
                    return cookie.substring(name.length + 1, cookie.length);
                }
            }
            return null;
        }

        function handleTrial() {
            setCookie('buttonHidden', 'true', 1);
            document.getElementById('main').style.display = 'none';
            document.getElementById('pleaseWait').style.display = 'block';
            window.location.href = "template/default/trial.php";
        }

        window.onload = function() {
            var cookieValue = getCookie('buttonHidden');
            if (cookieValue === 'true') {
                var trialButton = document.getElementById('trialButton');
                trialButton.style.display = 'none';
            }
        }
    </script>
</body>

</html>
END;

?>